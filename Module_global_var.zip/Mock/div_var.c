#include "my_header.h"
#define PATTERN_SIZE 5
int var;
void div_var()
{
	if(!(var%10))// Divisible by 10
		goto pattern;
	else 
	{
		printf("\n\n %d is not divisible by 10\n Hence not printing pattern...!\n",var);
		return;
	} 


	pattern:
	printf("\n\nPattern:: ");
	for(int r=1; r<= PATTERN_SIZE; r++)
	for(int c=1; c<= PATTERN_SIZE; c++)
	{
		int space=(PATTERN_SIZE - r);
		for(int i=0; i< space; i++)
			printf(" ");
		for(int i=0; i<r; i++)
		{
			char ch = 'a';
			printf("%c",ch+i);
		}
		printf("\n");
		break;
	}
	return;
}
