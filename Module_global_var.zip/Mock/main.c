#include "my_header.h"
int var=0;
int main()
{
        var=insert_arr();
	printf("\n Data in var: %d\n", var);
 
	if(!(var%2))// Even
		get_str();

	else  // ODD
		make_tree();
	
	div_var();
	
	printf("\n\n All task tested...\n");
	
	return 0;
}
