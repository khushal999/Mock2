#include <stdio.h>
#include <stdlib.h>

struct my_arr{
	int arr[4][3][2];
};

extern int var;

int insert_arr();
void get_str();
void make_tree();
void div_var();

