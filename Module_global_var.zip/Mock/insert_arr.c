#include "my_header.h"

int insert_arr()
{
	struct my_arr arr_data;
	int (*ptr)[3][2]= arr_data.arr;

		
	for(int i=0;i<4;i++)              
	{
		for(int j=0;j<3;j++)          
		{
			for(int k=0;k<2;k++)      
			{
				arr_data.arr[i][j][k]=rand();  
			}
		}
	}
	printf("\n Array data is:: \n");	  
	for(int i=0;i<4;i++)              
	{
		for(int j=0;j<3;j++)          
		{
			for(int k=0;k<2;k++)      
			{
				printf(" %d ",arr_data.arr[i][j][k]);  
			}
			printf("\n");
		}
		printf("\n");
	}
	***ptr = arr_data.arr[2][2][2];
	
	var=***ptr;
	return var;
}





/*EOC*/


